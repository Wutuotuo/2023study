﻿namespace Scripts.Weapon
{
   public interface IWeapon
   {
      void DoAttack();
   }
}
